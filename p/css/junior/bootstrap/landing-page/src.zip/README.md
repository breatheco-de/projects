# Simple Landing Page

This project was taken from the [Landing Page](http://startbootstrap.com/template-overviews/landing-page/) is a multipurpose landing page template for [Bootstrap](http://getbootstrap.com/) created by [Start Bootstrap](http://startbootstrap.com/).

## Goal

Demonstrate how you can build beautiful landing pages with just a few lines of code, thanks to the
bootstrap CSS framework.

## Technologies

HTML5 and CSS.