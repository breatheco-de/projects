#The Super Photo Feed

This is an improoved version of the first instagram exercise [http://projects.breatheco.de/p/css/beginner/other/instagram-feed/](http://projects.breatheco.de/p/css/beginner/other/instagram-feed/)

The main goal is to improove our skills in the grid system and start using bootstrap components.

##Technologies, Libraries
HTML5, CSS3, Bootstrap.

1. Bootstrap.
2. jQuery.
3. Font Awesome.
