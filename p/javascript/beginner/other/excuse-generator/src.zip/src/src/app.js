import './css/style.scss';

var theMain = function(){ 
    console.log('theMain is excuted'); 
    
    var theButtonNode = document.querySelector('.gen');
    theButtonNode.addEventListener('click',generateExcuse);
}

var generateExcuse = function(){ 
    console.log('the excuse is generated'); 
    
    var article = ['A','The','An'];
    var nouns = ['baby', 'Harry Potter'];
    var verbs = ['eat', 'spit'];
    var locations = ['on my knees', 'above my head'];
    var space = ' ';
    
    var x = Math.floor(Math.random() * article.length);
    var y = Math.floor(Math.random() * nouns.length);
    var z = Math.floor(Math.random() * verbs.length);
    var a = Math.floor(Math.random() * locations.length);
    
    var excuse = article[x] + space + nouns[y] + space + verbs[z] + space + locations[a];
    
    document.querySelector('#theexcuse').innerHTML = excuse;
    
}

window.onload = theMain;