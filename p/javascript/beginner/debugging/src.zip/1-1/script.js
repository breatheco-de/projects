function readyFunction(){
	alert("congratulations, script is being included!");
}