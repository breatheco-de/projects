function readyFunction(){
	debugger;
	alert("congratulations, you fixed it!');	
}