#MP3 Player

Lets create a MP3 player like spotify!

##Fundamentals
This exercise covers the following fundamentals:
1. Advanced CSS and HTML
2. The *audio* tag to emulate an HTML5 player.
3. Javascriopt Modules.
4. Javascript advanced programing practices.
5. Workign With The DOM.