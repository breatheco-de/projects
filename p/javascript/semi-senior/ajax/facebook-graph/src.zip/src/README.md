#Simple Public Facebook Graph Request

Very simple call to the facebook graph API to request the shares and comments over an URL.

##Fundamentals
This exercise covers the following fundamentals:
1. Connecting to facebook API
2. Using XMLHttpRequest object ot make AJAX Calls.
3. Understanding and reading/parsing the JSON
4. Displaying the resuld using Javascript and InnerHTML