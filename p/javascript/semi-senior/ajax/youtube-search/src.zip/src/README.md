#Search Youtube Videos

##Requierments

Use the Google Sign-In API to login the user into google asking for Youtube's basic permitions,
and search for videos in Youtube.

##Steps
1. Create the HTML and CSS for the project, prepare the Event Map and cearfuly plan your event handlers.

2. Login into google

Here is a documentation on how to implement your Google login:
https://developers.google.com/youtube/v3/guides/auth/client-side-web-apps

3. Search the videos from the Youtube API
 
Here is a QuickStart on Youtube API for websites:
https://developers.google.com/youtube/v3/quickstart/js